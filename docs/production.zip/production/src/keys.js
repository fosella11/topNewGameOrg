module.exports = {

    database: {
        connectionLimit: 10,
        host: 'localhost',
        user: 'fd',
        password: 'fede425929',
        database: 'db_topng'
    }

};